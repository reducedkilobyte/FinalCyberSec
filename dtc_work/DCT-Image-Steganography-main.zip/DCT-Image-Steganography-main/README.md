# DCT-Image-Steganography
For details on the theoretical foundations behind this Python application, please read the project report in the repo. 


"zigzag.py" location source: https://github.com/amzhang1/simple-JPEG-compression/blob/master/zigzag.py
